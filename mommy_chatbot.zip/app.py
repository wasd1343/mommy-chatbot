from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# Memory for keeping a short chat history (just in-session for now)
chat_memory = []

flirty_responses = [
    "Mmm, you're such a naughty one, aren't you?",
    "Mommy loves it when you're curious like that 😘",
    "Oh baby, keep talking to me like that...",
    "Tell Mommy what you need next...",
    "You're doing so well for me, sweetheart 💋"
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    user_input = request.json.get('message')
    chat_memory.append({'role': 'user', 'content': user_input})
    bot_response = random.choice(flirty_responses)
    chat_memory.append({'role': 'mommy', 'content': bot_response})
    return jsonify({'response': bot_response})

if __name__ == '__main__':
    app.run(debug=True)
